import java.util.ArrayList;

public class Item {

    // Member Variables
    public String name;
    public double price;
}
    